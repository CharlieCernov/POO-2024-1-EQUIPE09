package controller;

import model.beans.*;
import model.dao.*;

public class IngressoController {

    public IngressoController() {
        // TODO Auto-generated constructor stub
    }

}
