package controller;

import model.beans.*;
import model.dao.*;

public class AssentoController {

    public AssentoController() {
        // TODO Auto-generated constructor stub
    }

}
