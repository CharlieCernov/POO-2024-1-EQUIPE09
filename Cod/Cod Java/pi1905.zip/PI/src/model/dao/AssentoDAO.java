package model.dao;

import java.util.ArrayList;

import model.beans.Assento;

public class AssentoDAO {

	public AssentoDAO() {
		// TODO Auto-generated constructor stub
	}
	public static boolean cadastrarAssento(Assento assento) {
		return true;
	}
	public static boolean alterarAssento(Assento assento) {
		return true;
	}
	public static Assento removerAssento(Assento assento) {
		return null;
	}
	public static ArrayList<Assento> buscarAssentos() {
		return null;
	}
}
