package controller;
import model.beans.*;
import model.dao.*;
public class VendaController {

	public VendaController() {
		// TODO Auto-generated constructor stub
	}

}
