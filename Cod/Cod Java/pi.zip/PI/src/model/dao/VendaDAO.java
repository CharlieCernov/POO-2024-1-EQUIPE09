package model.dao;

import java.util.ArrayList;

import model.beans.Venda;

public class VendaDAO {

	public VendaDAO() {
		// TODO Auto-generated constructor stub
	}
	public static boolean cadastrarVenda(Venda venda) {
		return true;
	}
	public static boolean alterarVenda(Venda venda) {
		return true;
	}
	public static Venda removerVenda(Venda venda) {
		return null;
	}
	public static ArrayList<Venda> buscarVendas() {
		return null;
	}
}
